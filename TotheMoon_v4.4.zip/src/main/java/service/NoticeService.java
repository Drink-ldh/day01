package service;

import java.util.List;

import dao.NoticeDAO;
import vo.BoardVO;
import vo.NoticeVO;

public class NoticeService {
	private NoticeDAO dao;

	private static NoticeService service;

	private NoticeService() {
		dao = NoticeDAO.getInstance();
	}

	public static NoticeService getInstance() {
		if (service == null)
			service = new NoticeService();
		return service;
	}

	// insert
	public int insertNotice(NoticeVO nvo) {
		dao.insertNotice(nvo);
		return dao.getNoticeNo(nvo).getNotice_no();
	}

	// delete
	public int deleteNotice(int noticeNo) {
		return dao.deleteNotice(noticeNo);
	}

	// update
	public int updateNotice(NoticeVO nvo) {
		return dao.updateNotice(nvo);
	}

	// selectAll
	public List<NoticeVO> getAllNoticeList() {
		return dao.getAllNoticeList();
	}

	// selectCount
	public int getNoticeCount(int noticeNo) {
		return dao.getNoticeCount(noticeNo);
	}

	// searchByTitle
	public List<NoticeVO> searchByTitle(String keyword) {
		return dao.searchByTitle(keyword);
	}

	// viewContent
	public NoticeVO viewContent(int noticeNo) {
		dao.countHit(noticeNo);
		return dao.viewContent(noticeNo);
	}

	// 조회수 안오르는 글 보기
	public NoticeVO getContent(int noticeNo) {
		return dao.viewContent(noticeNo);
	}

	// imgDelete
	public int noticeImgDelete(int noticeNo) {
		return dao.noticeImgDelete(noticeNo);
	}

	// imgUpdate
	public int noticeImgUpdate(NoticeVO nvo) {
		return dao.noticeImgUpdate(nvo);
	}
}
