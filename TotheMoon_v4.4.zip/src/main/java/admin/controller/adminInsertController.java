package admin.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.AdminService;
import vo.AdminVO;


@WebServlet("/admin/adminInsert.do")
public class adminInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/adminInsert.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String admin_name = request.getParameter("name");
		String admin_id = request.getParameter("id");
		String admin_pass = request.getParameter("password");
		
		response.setCharacterEncoding("utf-8");
		response.setContentType("html/text; charset=utf-8;");
		
		AdminVO vo = null;
		
		vo = new AdminVO(admin_id, admin_pass, admin_name);
		
		AdminService service = AdminService.getInstance();
		
		service.insertAdmin(vo);
		
//		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/adminList.jsp");
//		rd.forward(request, response);
		
//		request.setAttribute("BoardVO", bvo);
//
		response.sendRedirect(request.getContextPath() + "/admin/adminList.do");
	}

}
