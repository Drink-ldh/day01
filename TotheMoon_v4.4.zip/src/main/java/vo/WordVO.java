package vo;

public class WordVO {
	private String word;

	public WordVO(String word) {
		this.word = word;
	}
	
	public WordVO() {
	}

	public String getWord() {
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}
	 
}

