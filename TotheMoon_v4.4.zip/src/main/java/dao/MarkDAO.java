package dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import util.SqlMapClientFactory;
import vo.MarkVO;

public class MarkDAO {
	private static MarkDAO dao;

	private SqlMapClient smc; // ibatis용 SqlMapClient객체 변수 선언

	private MarkDAO() {
		smc = SqlMapClientFactory.getSqlMapClient();
	}

	public static MarkDAO getInstance() {
		if (dao == null)
			dao = new MarkDAO();
		return dao;
	}

	// insert
	public int insertMark(MarkVO mvo) {
		int cnt = 0;
		try {
			Object obj = smc.insert("mark.insertMark", mvo);
			if (obj == null) {
				cnt = 1;
			}

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// delete
	public int deleteMark(String markNo) {
		int cnt = 0;
		try {
			cnt = smc.delete("mark.deleteMark", markNo);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// selectAll
	public List<MarkVO> getAllMarkList() {
		List<MarkVO> list = null;
		try {
			list = smc.queryForList("mark.getAllMarkList");
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}

		return list;
	}

	// selectCount
	public int getMarkCount(String markNo) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("mark.getMarkCount", markNo);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}

		return count;
	}

	// memberMarkList
	public MarkVO memberMarkList(String memCode) {
		MarkVO mvo = null;
		try {
			mvo = (MarkVO) smc.queryForObject("mark.memberMarkList", memCode);
		} catch (SQLException e) {
			mvo = null;
			e.printStackTrace();
		}

		return mvo;
	}

	// markMemberList
	public MarkVO markMemberList(String coinCode) {
		MarkVO mvo = null;
		try {
			mvo = (MarkVO) smc.queryForObject("mark.memberMarkList", coinCode);
		} catch (SQLException e) {
			mvo = null;
			e.printStackTrace();
		}

		return mvo;
	}

	// memberMarkCount
	public int memberMarkCount(String memCode) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("mark.memberMarkCount", memCode);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}
		return count;
	}

	// markMemberCount
	public int markMemberCount(String coinCode) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("mark.markMemberCount", coinCode);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}
		return count;
	}
}
