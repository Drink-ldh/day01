package member.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.MemberService;
import vo.MemberVO;



@WebServlet("/member/memberInsert.do")
public class MemberInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/memberForm.jsp");
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		String mem_code = request.getParameter("mem_code");
		String mem_nickname = request.getParameter("mem_nickname");
		String mem_pass = request.getParameter("mem_pass");


		MemberVO memVo = new MemberVO();
		memVo.setMem_code(mem_code);
		memVo.setMem_nickname(mem_nickname);
		memVo.setMem_pass(mem_pass);


		MemberService service = MemberService.getInstance();
		service.insertMember(memVo);

		response.sendRedirect(request.getContextPath() + "/testServlet");


	}

}







