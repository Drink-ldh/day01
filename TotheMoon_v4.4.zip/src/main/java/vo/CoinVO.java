package vo;

public class CoinVO {
	private String coin_code;
	private String coin_knm;
	private String img_id;
	private String coin_enm;
	private String coin_content001;
	private String coin_content002;
	private String coin_content003;
	@Override
	public String toString() {
		return "CoinVO [coin_code=" + coin_code + ", coin_knm=" + coin_knm + ", img_id=" + img_id + ", coin_enm="
				+ coin_enm + ", coin_content001=" + coin_content001 + ", coin_content002=" + coin_content002
				+ ", coin_content003=" + coin_content003 + "]";
	}
	public String getCoin_code() {
		return coin_code;
	}
	public void setCoin_code(String coin_code) {
		this.coin_code = coin_code;
	}
	public String getCoin_knm() {
		return coin_knm;
	}
	public void setCoin_knm(String coin_knm) {
		this.coin_knm = coin_knm;
	}
	public String getImg_id() {
		return img_id;
	}
	public void setImg_id(String img_id) {
		this.img_id = img_id;
	}
	public String getCoin_enm() {
		return coin_enm;
	}
	public void setCoin_enm(String coin_enm) {
		this.coin_enm = coin_enm;
	}
	public String getCoin_content001() {
		return coin_content001;
	}
	public void setCoin_content001(String coin_content001) {
		this.coin_content001 = coin_content001;
	}
	public String getCoin_content002() {
		return coin_content002;
	}
	public void setCoin_content002(String coin_content002) {
		this.coin_content002 = coin_content002;
	}
	public String getCoin_content003() {
		return coin_content003;
	}
	public void setCoin_content003(String coin_content003) {
		this.coin_content003 = coin_content003;
	}



}
