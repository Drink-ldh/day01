package dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import util.SqlMapClientFactory;
import vo.ReplyVO;

public class ReplyDAO {
	private static ReplyDAO dao;

	private SqlMapClient smc; // ibatis용 SqlMapClient객체 변수 선언

	private ReplyDAO() {
		smc = SqlMapClientFactory.getSqlMapClient();
	}

	public static ReplyDAO getInstance() {
		if (dao == null)
			dao = new ReplyDAO();
		return dao;
	}

	// insert
	public int insertReply(ReplyVO rvo) {
		int cnt = 0;
		try {
			Object obj = smc.insert("reply.insertReply", rvo);
			if (obj == null) {
				cnt = 1;
			}

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// delete
	public int deleteReply(int replyNo) {
		int cnt = 0;
		try {
			cnt = smc.delete("reply.deleteReply", replyNo);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// update
	public int updateReply(ReplyVO rvo) {
		int cnt = 0;
		try {
			cnt = smc.update("reply.updateReply", rvo);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// selectAll
	public List<ReplyVO> getAllReplyList() {
		List<ReplyVO> list = null;
		try {
			list = smc.queryForList("reply.getAllReplyList");
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}

		return list;
	}

	// selectCount
	public int getReplyCount(int replyNo) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("reply.getReplyCount", replyNo);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}

		return count;
	}

	// replyOfBoard
	public List<ReplyVO> replyOfBoard(String boardNo) {
		List<ReplyVO> list = null;
		try {
			list = smc.queryForList("reply.replyOfBoard", boardNo);
		} catch (SQLException e) {
			System.out.println("reply dao 에러");
			list = null;
		}

		return list;
	}
	
	public ReplyVO getRecentReply(String memCode) {
		ReplyVO vo = null;
		try {
			vo = (ReplyVO) smc.queryForObject("reply.getRecentReply", memCode);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vo;
		
	}
	
	public ReplyVO selectByNo(int no) {
		ReplyVO vo = null;
		try {
			vo = (ReplyVO) smc.queryForObject("reply.selectByNo", no);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return vo;
	}
	

}
