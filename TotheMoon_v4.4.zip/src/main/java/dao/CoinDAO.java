package dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import util.SqlMapClientFactory;
import vo.BoardVO;
import vo.CoinVO;

public class CoinDAO {
	private static CoinDAO dao;

	private SqlMapClient smc; // ibatis용 SqlMapClient객체 변수 선언

	private CoinDAO() {
		smc = SqlMapClientFactory.getSqlMapClient();
	}
	
	public static CoinDAO getInstance() {
		if (dao == null)
			dao = new CoinDAO();
		return dao;
	}
	
	// insert
	public int insertCoin(CoinVO cvo) {
		int cnt = 0;
		try {
			Object obj = smc.insert("coin.insertCoin", cvo);
			if (obj == null) {
				cnt = 1;
			}

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// delete
	public int deleteCoin(String coinCode) {
		int cnt = 0;
		try {
			cnt = smc.delete("coin.deleteCoin", coinCode);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// update
	public int updateCoin(CoinVO cvo) {
		int cnt = 0;

		try {
			cnt = smc.update("coin.updateCoin", cvo);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// selectAll
	public List<CoinVO> getAllCoinList() {
		List<CoinVO> list = null;
		try {
			list = smc.queryForList("coin.getAllCoinList");
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}

		return list;
	}

	// selectCount
	public int getCoinCount(String coinCode) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("coin.getCoinCount", coinCode);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}

		return count;
	}

	// viewContent
	public CoinVO viewContent(String coinCode) {
		CoinVO cvo = null;
		try {
			cvo = (CoinVO) smc.queryForObject("coin.viewContent", coinCode);

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cvo;
	}

	// searchByCode
	public List<CoinVO> searchCoinByCode(String keyword) {
		List<CoinVO> list = null;

		try {
			list = smc.queryForList("coin.searchCoinByCode", keyword);
		} catch (SQLException e) {
			list = null;
		}

		return list;
	}

	// searchByKorName
	public List<CoinVO> searchCoinByKnm(String keyword) {
		List<CoinVO> list = null;

		try {
			list = smc.queryForList("coin.searchCoinByKnm", keyword);
		} catch (SQLException e) {
			list = null;
		}

		return list;
	}

	// searchByEngName
	public List<CoinVO> searchCoinByEnm(String keyword) {
		List<CoinVO> list = null;

		try {
			list = smc.queryForList("coin.searchCoinByEnm", keyword);
		} catch (SQLException e) {
			list = null;
		}

		return list;
	}
}
