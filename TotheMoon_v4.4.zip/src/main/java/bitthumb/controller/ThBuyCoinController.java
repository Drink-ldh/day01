package bitthumb.controller;

public class ThBuyCoinController {

}
