package vo;

public class MessageVO {
	private int msg_check;
	private String msg_content;
	private String msg_date;
	private String msg_sender;
	private String msg_receiver;
	private String msg_no;
	private String sender_nickname;
	private String receiver_nickname;
	
	public MessageVO(int msg_check, String msg_content, String msg_date, String msg_sender, String msg_receiver,
			String msg_no, String sender_nickname, String receiver_nickname) {
		this.msg_check = msg_check;
		this.msg_content = msg_content;
		this.msg_date = msg_date;
		this.msg_sender = msg_sender;
		this.msg_receiver = msg_receiver;
		this.msg_no = msg_no;
		this.sender_nickname = sender_nickname;
		this.receiver_nickname = receiver_nickname;
	}
	
	

	public MessageVO() {
	}

	public int getMsg_check() {
		return msg_check;
	}

	public void setMsg_check(int msg_check) {
		this.msg_check = msg_check;
	}

	public String getMsg_content() {
		return msg_content;
	}

	public void setMsg_content(String msg_content) {
		this.msg_content = msg_content;
	}

	public String getMsg_date() {
		return msg_date;
	}

	public void setMsg_date(String msg_date) {
		this.msg_date = msg_date;
	}

	public String getMsg_sender() {
		return msg_sender;
	}

	public void setMsg_sender(String msg_sender) {
		this.msg_sender = msg_sender;
	}

	public String getMsg_receiver() {
		return msg_receiver;
	}

	public void setMsg_receiver(String msg_receiver) {
		this.msg_receiver = msg_receiver;
	}

	public String getMsg_no() {
		return msg_no;
	}

	public void setMsg_no(String msg_no) {
		this.msg_no = msg_no;
	}



	public String getSender_nickname() {
		return sender_nickname;
	}

	public void setSender_nickname(String sender_nickname) {
		this.sender_nickname = sender_nickname;
	}

	public String getReceiver_nickname() {
		return receiver_nickname;
	}

	public void setReceiver_nickname(String receiver_nickname) {
		this.receiver_nickname = receiver_nickname;
	}



	public MessageVO(String msg_content, String msg_sender, String msg_receiver, String msg_no) {
		this.msg_content = msg_content;
		this.msg_sender = msg_sender;
		this.msg_receiver = msg_receiver;
		this.msg_no = msg_no;
	}
	
	



	public MessageVO(String msg_content, String msg_sender, String msg_receiver) {
		this.msg_content = msg_content;
		this.msg_sender = msg_sender;
		this.msg_receiver = msg_receiver;
	}



	@Override
	public String toString() {
		return "MessageVO [msg_check=" + msg_check + ", msg_content=" + msg_content + ", msg_date=" + msg_date
				+ ", msg_sender=" + msg_sender + ", msg_receiver=" + msg_receiver + ", msg_no=" + msg_no
				+ ", sender_nickname=" + sender_nickname + ", receiver_nickname=" + receiver_nickname + "]";
	}
	
	
	
	
}
