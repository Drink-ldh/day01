package notice.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.NoticeService;
import vo.NoticeVO;

@WebServlet("/notice/noticeContent.do")
public class NoticeContentController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String noticestr = request.getParameter("notice_no");
		int noticeNo = Integer.parseInt(noticestr);
		
		NoticeService service = NoticeService.getInstance();
		NoticeVO nvo = service.viewContent(noticeNo);
		
		request.setAttribute("noticeVO", nvo);
		
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/noticeContent.jsp");
			rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
