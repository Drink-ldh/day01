package board.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.BoardService;
import service.WordService;
import vo.BoardVO;
import vo.WordVO;

@WebServlet("/board/boardInsert.do")
public class BoardInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String coin_code = request.getParameter("coin_code");
		request.setAttribute("coin_code", coin_code);
		
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/boardInsert.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String mem_code = request.getParameter("mem_code");
		String board_title = request.getParameter("board_title");
		String board_content = request.getParameter("board_content");
		String coin_code = request.getParameter("coin_code");
		
		response.setCharacterEncoding("utf-8");
		response.setContentType("html/text; charset=utf-8;");
		BoardVO bvo = null;
		
		bvo = new BoardVO(board_title, board_content, mem_code, coin_code);
		
		BoardService board = BoardService.getInstance();
		WordService word = WordService.getInstance();
		List<WordVO> list = word.getAllWordList();
		  String inputTitle[] = null;

	      for (int i = 0; i < list.size(); i++) {
	         int strlength = 0;
	         if (board_title.contains(list.get(i).getWord())) {
	            board_title = board_title.replace(list.get(i).getWord(), list.get(i).getWord()+" ");
	            inputTitle = board_title.split(" ");
	            for (int j = 0; j < inputTitle.length; j++) {
	            	String goodTitle = "";
	               if (inputTitle[j].equals(list.get(i).getWord())) {
	                  strlength = inputTitle[j].length();
	                  while (strlength-- > 0) {
	                     goodTitle += "♥";
	                  }
	                  if(board_title.contains(list.get(i).getWord()+" ")) {
	                	  board_title = board_title.replace(list.get(i).getWord()+" ", goodTitle);
	                  } else if(board_title.contains(" "+list.get(i).getWord())) {
	                	  board_title = board_title.replace(" "+list.get(i).getWord(), goodTitle);
	                  } else {
	                	  board_title = board_title.replace(list.get(i).getWord(), goodTitle);
	                  }
	               } 
	            }
	         }
	      }
//////////////// 비속어 필터 로직//////////////////////////////////////////////////////////////////////////////////////////////////////
	      String inputContent[] = null;

	      for (int i = 0; i < list.size(); i++) {
	         int strlength = 0;
	         if (board_content.contains(list.get(i).getWord())) {
	        	 board_content = board_content.replace(list.get(i).getWord(), list.get(i).getWord()+" ");
	            inputContent = board_content.split(" ");
	            for (int j = 0; j < inputContent.length; j++) {
	            	String goodWord = "";
	               if (inputContent[j].equals(list.get(i).getWord())) {
	                  strlength = inputContent[j].length();
	                  while (strlength-- > 0) {
	                     goodWord += "♥";
	                  }
	                  if(board_content.contains(list.get(i).getWord()+" ")) {
	                	  board_content = board_content.replace(list.get(i).getWord()+" ", goodWord);
	                  } else if(board_title.contains(" "+list.get(i).getWord())) {
	                	  board_content = board_content.replace(" "+list.get(i).getWord(), goodWord);
	                  } else {
	                	  board_content = board_content.replace(list.get(i).getWord(), goodWord);
	                  }
	               } 
	            }
	         }
	      }
		
//		System.out.println(board_title);
//		System.out.println(board_content);
//		System.out.println(mem_code);
//		System.out.println(coin_code);
		board_content = board_content.replaceAll("\r\n|\r|\n", "<br>");
		bvo = new BoardVO(board_title, board_content, mem_code, coin_code);
//		System.out.println("컨트롤러---->memCode: "+bvo.getMem_code());
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		String boardNo = "";
		switch (coin_code) {
		case "COIN":
			boardNo = board.insertBoard(bvo);
			break; 
		case "BTC":
			boardNo = board.insertBtcBoard(bvo);
			break;
		case "ETH":
			boardNo = board.insertEthBoard(bvo);
			break;
		case "XRP":
			boardNo = board.insertXrpBoard(bvo);
			break;
		case "DOGE":
			boardNo = board.insertDogeBoard(bvo);
			break;
		default:
			break;
		}
		
//		bvo.setBoard_no(boardNo);
		request.setAttribute("BoardVO", bvo);

		response.sendRedirect(request.getContextPath() + "/board/boardContent.do?board_no=" + boardNo);
	}

}
