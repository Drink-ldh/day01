package dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import util.SqlMapClientFactory;
import vo.MemberVO;

public class MemberDAO {
	private static MemberDAO dao;

	private SqlMapClient smc; // ibatis용 SqlMapClient객체 변수 선언

	private MemberDAO() {
		smc = SqlMapClientFactory.getSqlMapClient();
	}

	public static MemberDAO getInstance() {
		if (dao == null)
			dao = new MemberDAO();
		return dao;
	}

	// insert
	public int insertMember(MemberVO mvo) {
		int cnt = 0;
		try {
			Object obj = smc.insert("member.insertMember", mvo);
			if (obj == null) {
				cnt = 1;
			}

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// update
	public int updateMember(MemberVO mvo) {
		int cnt = 0;

		try {
			cnt = smc.update("member.updateMember", mvo);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// selectAll
	public List<MemberVO> getAllMemberList() {
		List<MemberVO> list = null;
		try {
			list = smc.queryForList("member.getAllMemberList");
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}

		return list;
	}

	// selectCount
	public int getMemberCount(String memCode) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("member.getMemberCount", memCode);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}
		return count;
	}
	
	// selectByMemCode
	public MemberVO selectByMemCode(String memCode) {
		MemberVO vo = null;
		try {
			vo = (MemberVO) smc.queryForObject("member.selectByMemCode", memCode);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vo;
	}
	
	// searchByMemCode
	public List<MemberVO> searchByMemCode(String memCode) {
		List<MemberVO> list = null;
		try {
			list = smc.queryForList("member.searchByMemCode", memCode);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	// seachByMemNickname
	public List<MemberVO> seachByMemNickname(String memCode) {
		List<MemberVO> list = null;
		try {
			list = smc.queryForList("member.seachByMemNickname", memCode);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public MemberVO login02(MemberVO memVO) {
		MemberVO memVo = null;
		try {
			memVo = (MemberVO) smc.queryForObject("member.login02", memVO);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return memVo;
	}
	
	public MemberVO logout02(MemberVO memVO) {
		MemberVO memVo = null;
		try {
			memVo = (MemberVO) smc.queryForObject("member.logout02", memVO);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return memVo;
	}
	
}
