package service;

import java.util.List;

import dao.AdminDAO;
import vo.AdminVO;

public class AdminService {
	private AdminDAO dao;

	private static AdminService service;

	private AdminService() {
		dao = AdminDAO.getInstance();
	}

	public static AdminService getInstance() {
		if (service == null)
			service = new AdminService();
		return service;
	}

	// insert
	public int insertAdmin(AdminVO vo) {
		return dao.insertAdmin(vo);
	}

	// delete
	public int deleteAdmin(String adminId) {
		return dao.deleteAdmin(adminId);
	}

	// selectAll
	public List<AdminVO> getAllAdmin() {
		return dao.getAllAdmin();
	}

	// selectOne
	public String getAdminOne(String adminId) {
		return dao.getAdminOne(adminId);
	}

	// selectCount
	public int getAdminCount(String adminId) {
		return dao.getAdminCount(adminId);
	}
}
