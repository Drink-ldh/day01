package notice.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.NoticeService;
import vo.NoticeVO;

/**
 * Servlet implementation class NoticeUpdateController
 */
@WebServlet("/admin/adminNoticeUpdate.do")
public class AdminNoticeUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String noticeStr = request.getParameter("notice_no");
		int noticeNo = Integer.parseInt(noticeStr);
		
		NoticeService service = NoticeService.getInstance();
		
		NoticeVO nvo = service.getContent(noticeNo);
		
		request.setAttribute("NoticeVO", nvo);
		
		request.getRequestDispatcher("/WEB-INF/view/adminNoticeUpdate.jsp")
		.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String notice_str = request.getParameter("notice_no");
		int notice_no = Integer.parseInt(notice_str);
		
		String notice_title = request.getParameter("notice_title");
		String notice_content = request.getParameter("notice_content");
		notice_content = notice_content.replaceAll("\r\n|\r|\n", "<br>");
		NoticeService service = NoticeService.getInstance();
		NoticeVO nvo = service.getContent(notice_no);
		nvo.setNotice_title(notice_title);
		nvo.setNotice_content(notice_content);
		
		service.updateNotice(nvo);
		
		response.sendRedirect(request.getContextPath() + "/admin/adminNoticeContent.do?notice_no=" + notice_no);
	}

}
