//컨테이너 바 좌우 버튼 활성화

$(document).ready(function(){
	
	$('ul.tabsMain li').click(function(){
		var tab_id = $(this).attr('data-tab');

		$('ul.tabsMain li').removeClass('currentMain');
		$('.tab-contentMain').removeClass('currentMain');

		$(this).addClass('currentMain');
		$("#"+tab_id).addClass('currentMain');
	})

})
//컨테이너 바 좌우 버튼 활성화


//업비트 스크립트
    function comma(str) {
        str = String(str);
        return str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,');
    }
    function setUpbitData(){
      $.ajax({
        url: "https://api.upbit.com/v1/market/all",
        dataType: "json"
      }).done(function(markets){
        //$("#tmp").html( JSON.stringify(markets) );
        let arr_UP_krw_markets = "";
        let arr_UP_korean_name = [];
        for(var i = 0; i < markets.length;i++){
          if( markets[i].market.indexOf("KRW") > -1 ){
            arr_UP_krw_markets += markets[i].market+(",");
            arr_UP_korean_name.push(markets[i].korean_name.replace("코인",""));
          }
        }
        arr_UP_krw_markets = arr_UP_krw_markets.substring(0, arr_UP_krw_markets.length-1);
        //$("#tmp").html( arr_krw_markets );
        $.ajax({
          url: "https://api.upbit.com/v1/ticker?markets=" +arr_UP_krw_markets,
          dataType: "json"
        }).done(function(tickers){
          $("#UP_table_ticker > tbody > tr").remove();
          //alert($("#table_ticker > tbody > tr").length);
          //$("#table_ticker").fadeOut("slow");

          for(let i = 0;i < tickers.length;i++){
            let rowHtml = "<tr><td>"+arr_UP_korean_name[i].replace("코인","").replace("토큰","")+"</td>";
            //rowHtml += "<td>" + arr_korean_name[i] +"</td>"
            rowHtml += "<td>" + comma(tickers[i].trade_price)+"</td>"
            if(tickers[i].signed_change_rate > 0){
              tickers[i].change_price = "+"+ tickers[i].change_price;
            } else if(tickers[i].signed_change_rate < 0) {
              tickers[i].change_price = "-" + tickers[i].change_price;
            }
            rowHtml += "<td>" + comma(tickers[i].change_price) + "(" + comma((tickers[i].signed_change_rate*100).toFixed(2))+"%)</td>"
            rowHtml += "<td>" + comma((     tickers[i].acc_trade_price_24h>1000000 ? ( tickers[i].acc_trade_price_24h / 1000000 ) : tickers[i].acc_trade_price_24h ).toFixed(0)) + (tickers[i].acc_trade_price_24h>1000000 ? "백만" : "") + "</td>"
            rowHtml += "</tr>";
            $("#UP_table_ticker > tbody:last").append(rowHtml);
            //markets[i].korean_name
          } // end for...
          //$("#UP_table_ticker").fadeIn("slow");
        })  //done(function(tickers){
      }) // end done(function(markets){
      .fail(function(){
        //alert("업비트 API 접근 중 에러.")}
        $("#UP_tmp").text( "API 접근 중 에러." );
      })
      //setTimeout(setUpbitData, 13000);
    }
    $(function() {
      var color = localStorage.getItem("test_upbit_color");
      if( color ) $("body").css("color", color);
      setUpbitData();
    });
//업비트 스크립트


//
////빗썸 스크립트
//    function comma(str) {
//        str = String(str);
//        return str.replace(/(\d)(?=(?:\d{3})+(?!\d))/g, '$1,');
//    }
//    function setBitthumbData() {
//        $.ajax({
//            url: "https://api.bithumb.com/public/ticker/ALL",
//            dataType: "json",
//            success: function (markets) {
//                let arr_TH_krw_markets = []; //코인종류
//                let arr_TH_closing_price = []; //시가
//                let arr_TH_fluctate = []; // 변동가
//                let arr_TH_fluctate_rate = []; // 변동률
//                let arr_TH_acc_trade_value = [];
//                //  let arr_TH_korean_name = [];
//                $.each(markets.data, function (i, v) {
//                    arr_TH_krw_markets.push(i);
//                    arr_TH_closing_price.push(v.closing_price);
//                    arr_TH_fluctate.push(v.fluctate_24H);
//                    arr_TH_fluctate_rate.push(v.fluctate_rate_24H);
//                    arr_TH_acc_trade_value.push(v.acc_trade_value_24H);
//                })
//
//                let code = "";
//
//                for (var i = 0; i < arr_TH_krw_markets.length-1; i++) {
//
//                     let rowHtml = "<tr><td>" + arr_TH_krw_markets[i] + "</td>"
//                         rowHtml += "<td>" + comma(arr_TH_closing_price[i]) + "</td>"
//                         if(arr_TH_fluctate[i] > 0){
//                             arr_TH_fluctate[i] = "+"+ arr_TH_fluctate[i];
//                         }
//                         rowHtml += "<td>" + comma(arr_TH_fluctate[i]) + "(" + arr_TH_fluctate_rate[i] + "%)</td>"
//                         rowHtml += "<td>" + comma((arr_TH_acc_trade_value[i] > 1000000 ? (arr_TH_acc_trade_value[i] / 1000000) : arr_TH_acc_trade_value[i]).toFixed(0)) + (arr_TH_acc_trade_value[i] > 1000000 ? "백만" : "") + "</td>"
//                         rowHtml += "</tr>";
//                         $('#TH_table_ticker > tbody:last').append(rowHtml);
//                }
//
//
//                //    console.log(markets.data.BTC.closing_price);
//            },
//            error: function (xhr) {
//                console.log(xhr);
//            }
//        });
//    }
//    $(function (){
//        setBitthumbData();
//      //  setInterval(setBitthumbData, 13000);
//    });
//


//빗썸 스크립트




//메뉴기능 스크립트
$(document).ready(function() {

   var topBar = $("#topBar").offset();

   $(window).scroll(function() {

      var docScrollY = $(document).scrollTop()
      var barThis = $("#topBar")
      var fixNext = $("#fixNextTag")

      if (docScrollY > topBar.top) {
         barThis.addClass("top_bar_fix");
         fixNext.addClass("pd_top_80");
      } else {
         barThis.removeClass("top_bar_fix");
         fixNext.removeClass("pd_top_80");
      }

   });

})

//2번쨰
$(document).ready(function() {

   var topBar = $("#topBar").offset();

   $(window).scroll(function() {

      var docScrollY = $(document).scrollTop()
      var barThis = $("#topBar")
      var fixNext = $("#fixNextTag2")

      if (docScrollY > topBar.top) {
         barThis.addClass("top_bar_fix");
         fixNext.addClass("pd_top_80");
      } else {
         barThis.removeClass("top_bar_fix");
         fixNext.removeClass("pd_top_80");
      }

   });

})

//메뉴기능 스크립트