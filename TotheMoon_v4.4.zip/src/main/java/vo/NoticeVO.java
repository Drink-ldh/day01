package vo;

public class NoticeVO {
	private int notice_no;
	private String notice_title;
	private String notice_content;
	private String notice_date;
	private String notice_hit;
	private String img_id;
	private String admin_id;
	public NoticeVO(int notice_no, String notice_title, String notice_content, String notice_date, String notice_hit,
			String img_id, String admin_id) {
		this.notice_no = notice_no;
		this.notice_title = notice_title;
		this.notice_content = notice_content;
		this.notice_date = notice_date;
		this.notice_hit = notice_hit;
		this.img_id = img_id;
		this.admin_id = admin_id;
	}
	
	
	public NoticeVO() {
	}

	


	public int getNotice_no() {
		return notice_no;
	}

	public void setNotice_no(int notice_no) {
		this.notice_no = notice_no;
	}

	public String getNotice_title() {
		return notice_title;
	}

	public void setNotice_title(String notice_title) {
		this.notice_title = notice_title;
	}

	public String getNotice_content() {
		return notice_content;
	}

	public void setNotice_content(String notice_content) {
		this.notice_content = notice_content;
	}

	public String getNotice_date() {
		return notice_date;
	}

	public void setNotice_date(String notice_date) {
		this.notice_date = notice_date;
	}

	public String getNotice_hit() {
		return notice_hit;
	}

	public void setNotice_hit(String notice_hit) {
		this.notice_hit = notice_hit;
	}

	public String getImg_id() {
		return img_id;
	}

	public void setImg_id(String img_id) {
		this.img_id = img_id;
	}

	public String getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(String admin_id) {
		this.admin_id = admin_id;
	}


	public NoticeVO(String notice_title, String notice_content, String admin_id) {
		this.notice_title = notice_title;
		this.notice_content = notice_content;
		this.admin_id = admin_id;
	}
	
	
}
