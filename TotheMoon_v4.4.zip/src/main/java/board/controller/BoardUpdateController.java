package board.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.BoardService;
import vo.BoardVO;

/**
 * Servlet implementation class BoardUpdateController
 */
@WebServlet("/board/boardUpdate.do")
public class BoardUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String board_no = request.getParameter("board_no");
		
		BoardService service = BoardService.getInstance();
		
		BoardVO bvo = service.getContent(board_no);
		
		request.setAttribute("BoardVO", bvo);
		
		request.getRequestDispatcher("/WEB-INF/view/boardUpdate.jsp")
		.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String board_no = request.getParameter("board_no");
		String board_title = request.getParameter("board_title");
		String board_content = request.getParameter("board_content");
//		board_content = board_content.replaceAll("/(?:\r\n|\r|\n)/g", "<br>");
		board_content = board_content.replaceAll("\r\n|\r|\n", "<br>");
		BoardService service = BoardService.getInstance();
		BoardVO bvo = service.getContent(board_no);
		bvo.setBoard_title(board_title);
		bvo.setBoard_content(board_content);
		
		service.updateBoard(bvo);
		
		response.sendRedirect(request.getContextPath() + "/board/boardContent.do?board_no=" + board_no);
		
	}

}
