package reply.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import service.MemberService;
import service.ReplyService;
import vo.MemberVO;
import vo.ReplyVO;

@WebServlet("/reply/replyInsert.do")
public class ReplyInsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("application/json; charset=utf-8");
		
		String board_no = request.getParameter("board_no");
		String mem_code = request.getParameter("mem_code");
		String reply_content = request.getParameter("reply_content");
		
		
		ReplyVO vo = new ReplyVO(reply_content, board_no, mem_code);
		ReplyService service = ReplyService.getInstance();
		Gson gson = new Gson();
		
		int cnt = service.insertReply(vo);
		ReplyVO recentReply = service.getRecentReply(mem_code);
		
		
		
		MemberService memberService = MemberService.getInstance();
		MemberVO memberVO = memberService.selectByMemCode(mem_code);
		String nickname = memberVO.getMem_nickname();
		
		recentReply.setMem_nickname(nickname);
		
		PrintWriter out = response.getWriter();
		out.println(gson.toJson(recentReply));
		response.flushBuffer();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
