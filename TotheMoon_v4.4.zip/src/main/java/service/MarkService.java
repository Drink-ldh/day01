package service;

import java.util.List;

import dao.MarkDAO;
import vo.MarkVO;

public class MarkService {
	private MarkDAO dao;

	private static MarkService service;

	private MarkService() {
		dao = MarkDAO.getInstance();
	}

	public static MarkService getInstance() {
		if (service == null)
			service = new MarkService();
		return service;
	}

	// insert
	public int insertMark(MarkVO mvo) {
		return dao.insertMark(mvo);
	}

	// delete
	public int deleteMark(String markNo) {
		return dao.deleteMark(markNo);
	}

	// selectAll
	public List<MarkVO> getAllMarkList() {
		return dao.getAllMarkList();
	}

	// selectCount
	public int getMarkCount(String markNo) {
		return dao.getMarkCount(markNo);
	}

	// memberMarkList
	public MarkVO memberMarkList(String memCode) {
		return dao.memberMarkList(memCode);
	}

	// markMemberList
	public MarkVO markMemberList(String coinCode) {
		return dao.markMemberList(coinCode);
	}

	// memberMarkCount
	public int memberMarkCount(String memCode) {
		return dao.memberMarkCount(memCode);
	}

	// markMamberCount
	public int markMamberCount(String coinCode) {
		return dao.markMemberCount(coinCode);
	}
}
