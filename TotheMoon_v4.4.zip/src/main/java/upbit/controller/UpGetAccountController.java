package upbit.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;


@WebServlet("/getAccountsUB.do")
public class UpGetAccountController extends HttpServlet {
   private static final long serialVersionUID = 1L;

   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      
      request.setCharacterEncoding("UTF-8");
      
      response.setCharacterEncoding("UTF-8");
      response.setContentType("application/json; charset=UTF-8");
      PrintWriter out = response.getWriter();
      
      String accessKey = "9VjUuTBHfNJzOhFWeWrrSWSMaGHfuVPsunhIjfFp";
      String secretKey = "BBRzuQzzSuRQPCmYww1P2ErFMuATTM5zCX4jPty5";
      
      String account = getAccounts(accessKey,secretKey);
      System.out.println(account);
      if(account != null) {
         System.out.println("계좌 호출 성공");
      } else {
         System.out.println("계좌 호출 실패"); 
      }
      out.println(account);
      response.flushBuffer();
      
   }

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      doGet(request, response);
   }
   
public static String getAccounts(String accessKey,String secretKey) {
       
       String result = "";
       
        String serverUrl = "https://api.upbit.com";

        Algorithm algorithm = Algorithm.HMAC256(secretKey);
        String jwtToken = JWT.create()
                .withClaim("access_key", accessKey)
                .withClaim("nonce", UUID.randomUUID().toString())
                .sign(algorithm);

        String authenticationToken = "Bearer " + jwtToken;

        try {
           
            HttpClient client = HttpClientBuilder.create().build();
            HttpGet request = new HttpGet(serverUrl + "/v1/accounts");
            request.setHeader("Content-Type", "application/json");
            request.addHeader("Authorization", authenticationToken);

            HttpResponse response = client.execute(request);
            HttpEntity entity = response.getEntity();
            
            result = EntityUtils.toString(entity, "UTF-8");
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

}