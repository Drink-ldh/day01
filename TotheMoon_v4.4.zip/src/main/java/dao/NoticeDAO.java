package dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import util.SqlMapClientFactory;
import vo.NoticeVO;

public class NoticeDAO {
	private static NoticeDAO dao;

	private SqlMapClient smc; // ibatis용 SqlMapClient객체 변수 선언

	private NoticeDAO() {
		smc = SqlMapClientFactory.getSqlMapClient();
	}

	public static NoticeDAO getInstance() {
		if (dao == null)
			dao = new NoticeDAO();
		return dao;
	}

	// insert
	public int insertNotice(NoticeVO nvo) {
		int cnt = 0;
		try {
			Object obj = smc.insert("notice.insertNotice", nvo);
			if (obj == null) {
				cnt = 1;
			}

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// delete
	public int deleteNotice(int noticeNo) {
		int cnt = 0;
		try {
			cnt = smc.delete("notice.deleteNotice", noticeNo);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// update
	public int updateNotice(NoticeVO nvo) {
		int cnt = 0;

		try {
			cnt = smc.update("notice.updateNotice", nvo);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// selectAll
	public List<NoticeVO> getAllNoticeList() {
		List<NoticeVO> list = null;
		try {
			list = smc.queryForList("notice.getAllNoticeList");
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}

		return list;
	}

	// selectCount
	public int getNoticeCount(int noticeNo) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("notice.getNoticeCount", noticeNo);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}

		return count;
	}

	// searchByTitle
	public List<NoticeVO> searchByTitle(String keyword) {
		List<NoticeVO> list = null;

		try {
			list = smc.queryForList("notice.searchByTitle", keyword);
		} catch (SQLException e) {
			list = null;
		}

		return list;
	}

	// viewContent
	public NoticeVO viewContent(int noticeNo) {
		NoticeVO nvo = null;
		try {
			nvo = (NoticeVO) smc.queryForObject("notice.viewContent", noticeNo);

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return nvo;
	}

	// 조회수 ++
	public void countHit(int noticeNo) {
		try {
			smc.update("notice.countHit", noticeNo);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// imgDelete
	public int noticeImgDelete(int noticeNo) {
		int cnt = 0;

		try {
			cnt = smc.update("notice.noticeImgDelete", noticeNo);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// imgUpdate
	public int noticeImgUpdate(NoticeVO nvo) {
		int cnt = 0;

		try {
			cnt = smc.update("notice.noticeImgUpdate", nvo);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// getNoticeNo
	public NoticeVO getNoticeNo(NoticeVO vo) {
		NoticeVO nvo = null;
		try {
			nvo = (NoticeVO) smc.queryForObject("notice.getNoticeNo", vo);

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return nvo;
	}
	
}
	
