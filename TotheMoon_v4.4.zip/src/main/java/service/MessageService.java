package service;

import java.sql.SQLException;
import java.util.List;

import dao.MessageDAO;
import vo.MessageVO;

public class MessageService {
	private MessageDAO dao;

	private static MessageService service;

	private MessageService() {
		dao = MessageDAO.getInstance();
	}

	public static MessageService getInstance() {
		if (service == null)
			service = new MessageService();
		return service;
	}

	// insert
	public int insertMessage(MessageVO mvo) {
		return dao.insertMessage(mvo);
	}

	// selectAll
	public List<MessageVO> getAllMessageList() {
		return dao.getAllMessageList();
	}

	// sendMessageList
	public List<MessageVO> sendMessageList(String msg_sender) {
		return dao.sendMessageList(msg_sender);
	}

	// receiverMessageList
	public List<MessageVO> userMessageList(String msg_receiver) {
		return dao.userMessageList(msg_receiver);
	}

	// selectCount
	public int getMessageCount(String msgNo) {
		return dao.getMessageCount(msgNo);
	}

	public MessageVO viewContent(String msgNo) {
		return dao.viewContent(msgNo);
	}

	// messageCheck
	public int messageCheck(String msgNo) {
		return dao.messageCheck(msgNo);
	}
	
	public int unreadCount(String msg_receiver) {
		return dao.unreadCount(msg_receiver);
	}
}
