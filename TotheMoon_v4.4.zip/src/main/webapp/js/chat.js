//채팅접속

document.getElementById("btnConnect").addEventListener("click", connectting, false);

function connectting(){
	$('#btnConnect').hide();
	chat = window.open("<%=request.getContextPath()%>/chat/webSocketMutiChatting.jsp", "채팅", "width=500, height=700, left=100, top=50");
	chat.addEventListener('beforeunload', function(){
		$('#btnConnect').show();
	
	})

}
