package bitthumb.controller;

public class ThGetCoinPriceController {

}
