package dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import util.SqlMapClientFactory;
import vo.MessageVO;

public class MessageDAO {
	private static MessageDAO dao;

	private SqlMapClient smc; // ibatis용 SqlMapClient객체 변수 선언

	private MessageDAO() {
		smc = SqlMapClientFactory.getSqlMapClient();
	}

	public static MessageDAO getInstance() {
		if (dao == null)
			dao = new MessageDAO();
		return dao;
	}

	// insert
	public int insertMessage(MessageVO mvo) {
		int cnt = 0;
		try {
			Object obj = smc.insert("message.insertMessage", mvo);
			if (obj == null) {
				cnt = 1;
			}

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// selectAll
	public List<MessageVO> getAllMessageList() {
		List<MessageVO> list = null;
		try {
			list = smc.queryForList("message.getAllMessageList");
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}

		return list;
	}

	// sendMessageList
	public List<MessageVO> sendMessageList(String msg_sender) {
		List<MessageVO> list = null;
		try {
			list = smc.queryForList("message.sendMessageList", msg_sender);
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}
		return list;
	}

	// receiverMessageList
	public List<MessageVO> userMessageList(String msg_receiver) {
		List<MessageVO> list = null;
		try {
			list = smc.queryForList("message.userMessageList", msg_receiver);
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}
		return list;
	}

	// selectCount
	public int getMessageCount(String msgNo) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("message.getMessageCount", msgNo);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}

		return count;
	}

	// viewContent
	public MessageVO viewContent(String msgNo) {
		MessageVO mvo = null;
		try {
			mvo = (MessageVO) smc.queryForObject("message.viewContent", msgNo);

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return mvo;
	}

	// messageCheck
	public int messageCheck(String msgNo) {
		int cnt = 0;

		try {
			cnt = smc.update("message.messageCheck", msgNo);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}
	
	public int unreadCount(String msg_receiver) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("message.unreadCount", msg_receiver);
		} catch (SQLException e) {
			System.out.println("dao 에러");
			e.printStackTrace();
		}
		return count;
	}
}
