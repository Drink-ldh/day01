
//예보
$("#weather").on('change',function(){   
   let url = "https://api.openweathermap.org/data/2.5/weather?q="
         + $(this).val()
         + "&appid=878f69284d01314ac7fbb82985236d86&units=metric";
   console.log($(this).val());
   
   
   
   
   
   


$.getJSON(url,
//$.getJSON('https://api.openweathermap.org/data/2.5/weather?q=Daejeon&appid=878f69284d01314ac7fbb82985236d86&units=metric',
      function(result){
         $('.time').empty();
   $('.ctemp').html("현재온도: " + result.main.temp + "℃");
   $('.lowtemp').html("최저온도: " + result.main.temp_min+ "℃");
   $('.hightemp').html("최고온도: " + result.main.temp_max+ "℃");
   var wiconUrl = '<img src="http://openweathermap.org/img/wn/'+result.weather[0].icon+'.png" alt="'+result.
   weather[0].description+'">'         
   $('.icon').html(wiconUrl);
   
   var ct = result.dt;
   console.log(result);
   
   function convertTime(t){
      var ot = new Date(t * 1000);
      
      var hr = ot.getHours();
      var m = ot.getMinutes();
      var s = ot.getSeconds();
      
      return '현재시간: ' + hr + ':' + m + ':' + s
      
   }
   
   
   var currentTime = convertTime(ct);
//   $('.time').empty();
      $('.time').append(currentTime);
});


//예보


//48시간 예보
$.getJSON('https://api.openweathermap.org/data/2.5/onecall?lat=37.5683&lon=126.9778&appid=878f69284d01314ac7fbb82985236d86&units=metric',
            function(result) {
         $('.time').empty();
         for(var i = 0; i < 48; i++){
            var ctime = result.hourly[i].dt;
            var ctemp = result.hourly[i].temp;

            function convertTime(ctime){
//                var ot = new Date(t * 1000);
               var ot = new Date(ctime * 1000);
               
               var dt = ot.getDate();
               var hr = ot.getHours();
               var m = ot.getMinutes();
               var s = ot.getSeconds();
               
               return '' + dt + '일&nbsp;&nbsp;' + hr + '시'
               
            }
            
            var currentTime = convertTime(ctime);
            var tableHtml = '<tr>' +
               '<td>' + currentTime + '&nbsp;&nbsp;</td>' +
               '<td>' + ctemp + '℃</td>' +
               '</tr>';
               
               
            $('.weatherContent').append(tableHtml);
         }
         
         
         var ct = result.current.dt;
   //console.log(result);
         
         var currentTime = convertTime(ct);
         
            $('.time').append(currentTime);
      });

});

$("#weather").trigger("change");

//48시간 예보