package vo;

public class UpbitVO {
	private String mem_code;
	private String up_secret;
	private String up_access;
	public UpbitVO(String mem_code, String up_secret, String up_access) {
		this.mem_code = mem_code;
		this.up_secret = up_secret;
		this.up_access = up_access;
	}
	public UpbitVO() {
	}
	public String getMem_code() {
		return mem_code;
	}
	public void setMem_code(String mem_code) {
		this.mem_code = mem_code;
	}
	public String getUp_secret() {
		return up_secret;
	}
	public void setUp_secret(String up_secret) {
		this.up_secret = up_secret;
	}
	public String getUp_access() {
		return up_access;
	}
	public void setUp_access(String up_access) {
		this.up_access = up_access;
	}
	
	
}
