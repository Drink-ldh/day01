package dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import util.SqlMapClientFactory;
import vo.BitthumbVO;

public class BitthumbDAO {
	private static BitthumbDAO dao;

	private SqlMapClient smc; // ibatis용 SqlMapClient객체 변수 선언

	private BitthumbDAO() {
		smc = SqlMapClientFactory.getSqlMapClient();
	}

	public static BitthumbDAO getInstance() {
		if (dao == null)
			dao = new BitthumbDAO();
		return dao;
	}

	// insert
	public int insertBitthumb(BitthumbVO bvo) {
		int cnt = 0;
		try {
			Object obj = smc.insert("bitthumb.insertBitthumb", bvo);
			if (obj == null) {
				cnt = 1;
			}

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// delete
	public int deleteBitthumb(String memCode) {
		int cnt = 0;
		try {
			cnt = smc.delete("bitthumb.deleteBitthumb", memCode);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// selectAll
	public List<BitthumbVO> getAllBitthumbList() {
		List<BitthumbVO> list = null;
		try {
			list = smc.queryForList("bitthumb.getAllBitthumbList");
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}

		return list;
	}

	// selectCount
	public int getBitthumbCount(String memCode) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("bitthumb.getBitthumbCount", memCode);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}

		return count;
	}

	// selectOne
	public BitthumbVO getBitthumbOne(String memCode) {
		BitthumbVO bvo = null;
		try {
			bvo = (BitthumbVO) smc.queryForObject("bitthumb.getBitthumbOne", memCode);
		} catch (SQLException e) {
			bvo = null;
			e.printStackTrace();
		}

		return bvo;
	}
}
