package api.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NewsController
 */
@WebServlet("/newsController.do")
public class NewsController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        
		String clientId = "a1Pl35DXUSvWGQ176NFj";//애플리케이션 클라이언트 아이디값";
        String clientSecret = "JuYSWgmGao";//애플리케이션 클라이언트 시크릿값";
        try {
            request.setCharacterEncoding("utf-8");
            response.setCharacterEncoding("utf-8");
            response.setContentType("application/json; charset=utf-8");
            String query = URLEncoder.encode(request.getParameter("query"), "UTF-8"); //검색어";
            String sort = request.getParameter("sort");	// 정렬 옵션: sim (유사도순), date (날짜순)
            String display = request.getParameter("display");	// 검색 결과 출력 건수 지정. 	10(기본값), 100(최대)
            String start = request.getParameter("start");			// 검색 시작 위치로 최대 1000까지 가능. 1(기본값), 1000(최대)
            
            System.out.println(display);
            System.out.println(start);
           
            String apiURL = "https://openapi.naver.com/v1/search/news.json?query="+ query + "&display=" + display + "&start="+start+"&sort="+sort; // 뉴스의 json 결과
            URL url = new URL(apiURL);
            HttpURLConnection con = (HttpURLConnection)url.openConnection();
            con.setRequestMethod("GET");
            con.setRequestProperty("X-Naver-Client-Id", clientId);
            con.setRequestProperty("X-Naver-Client-Secret", clientSecret);
            int responseCode = con.getResponseCode();
            BufferedReader br;
            if(responseCode==200) { // 정상 호출
                br = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
            } else {  // 에러 발생
                br = new BufferedReader(new InputStreamReader(con.getErrorStream(), "UTF-8"));
            }
            String inputLine;
            StringBuffer strBuffer = new StringBuffer();
            while ((inputLine = br.readLine()) != null) {
                strBuffer.append(inputLine);
            }
            br.close();
            System.out.println(strBuffer.toString());
            PrintWriter out = response.getWriter();
            out.print(strBuffer.toString());
        } catch (Exception e) {
            System.out.println(e);
        }
	
	
	
	
	
	
	
	
	
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
