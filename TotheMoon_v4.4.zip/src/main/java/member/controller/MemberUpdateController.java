package member.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.MemberService;
import vo.MemberVO;




@WebServlet("/member/memberUpdate.do")
public class MemberUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 회원ID를 파라미터로 받아서 해당 회원 정보를 구해서 Update Form으로 보낸다.
		request.setCharacterEncoding("utf-8");

		String mem_code = request.getParameter("mem_code");

		MemberService service = MemberService.getInstance();

		MemberVO memVo = service.selectByMemCode(mem_code);

		request.setAttribute("memberVO02", memVo);

		request.getRequestDispatcher("/WEB-INF/view/memberUpdateForm.jsp")
		.forward(request, response);


	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// 수정할 회원 정보를 파라미터로 받아서 DB의 회원정보를 수정한 후 List로 이동한다.
		request.setCharacterEncoding("utf-8");

		// 요청할 때 파라미터로 온 데이터 구하기
		String mem_code = request.getParameter("mem_code");
		String mem_nickname = request.getParameter("mem_nickname");
		String mem_pass = request.getParameter("mem_pass");

		// 데이터를 VO객체에 저장하기
		MemberVO memVo = new MemberVO();
		memVo.setMem_code(mem_code);
		memVo.setMem_nickname(mem_nickname);
		memVo.setMem_pass(mem_pass);

		MemberService service = MemberService.getInstance();

		service.updateMember(memVo);

		response.sendRedirect(request.getContextPath() + "/member/memberList.do");

	}

}
