package word.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import service.WordService;
import vo.WordVO;

@WebServlet("/admin/wordAdd.do")
public class WordAddController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("application/json; charset=utf-8");
		
		String newWord = request.getParameter("newWord");
		WordService service = WordService.getInstance();
		
		int insertWord = service.insertWord(newWord);
		String result = null;
		if (insertWord >0) {
			result = "success";
		}else {
			result = "fail";
		}
		Map<String,String> map = new HashMap< >();
		map.put("newWord", newWord);
		map.put("result", result);
		Gson gson = new Gson();
		PrintWriter out = response.getWriter();
		out.println(gson.toJson(map));
		response.flushBuffer();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
