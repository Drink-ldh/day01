package bitthumb.controller;

public class asdasdasd {
	
	public static void main(String[] args) {
		
	}

}
