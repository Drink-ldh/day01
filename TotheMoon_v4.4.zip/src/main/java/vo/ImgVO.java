package vo;

public class ImgVO {
	private String img_id;
	private String img_name;
	private String img_folder;
	public ImgVO(String img_id, String img_name, String img_folder) {
		this.img_id = img_id;
		this.img_name = img_name;
		this.img_folder = img_folder;
	}
	public ImgVO() {
	}
	public String getImg_id() {
		return img_id;
	}
	public void setImg_id(String img_id) {
		this.img_id = img_id;
	}
	public String getImg_name() {
		return img_name;
	}
	public void setImg_name(String img_name) {
		this.img_name = img_name;
	}
	public String getImg_folder() {
		return img_folder;
	}
	public void setImg_folder(String img_folder) {
		this.img_folder = img_folder;
	}
	
	
}
