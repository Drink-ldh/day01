package dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import util.SqlMapClientFactory;
import vo.WordVO;

public class WordDAO {
	private static WordDAO dao;

	private SqlMapClient smc; // ibatis용 SqlMapClient객체 변수 선언

	private WordDAO() {
		smc = SqlMapClientFactory.getSqlMapClient();
	}

	public static WordDAO getInstance() {
		if (dao == null)
			dao = new WordDAO();
		return dao;
	}

	// insert
	public int insertWord(String word) {
		int cnt = 0;
		try {
			Object obj = smc.insert("word.insertWord", word);
			if (obj == null) {
				cnt = 1;
			}

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// delete
	public int deleteWord(String word) {
		int cnt = 0;
		try {
			cnt = smc.delete("word.deleteWord", word);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// selectAll
	public List<WordVO> getAllWordList() {
		List<WordVO> list = null;
		try {
			list = smc.queryForList("word.getAllWordList");
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}

		return list;
	}

	// selectCount
	public int getWordCount(String word) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("word.getWordCount", word);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}

		return count;
	}

	// selectOne
	public WordVO getWordOne(String word) {
		WordVO uvo = null;
		try {
			uvo = (WordVO) smc.queryForObject("word.getWordOne", word);
		} catch (SQLException e) {
			uvo = null;
			e.printStackTrace();
		}

		return uvo;
	}
}
