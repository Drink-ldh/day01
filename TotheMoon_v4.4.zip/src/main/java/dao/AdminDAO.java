package dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import util.SqlMapClientFactory;
import vo.AdminVO;

public class AdminDAO {
	private static AdminDAO dao;

	private SqlMapClient smc; // ibatis용 SqlMapClient객체 변수 선언

	private AdminDAO() {
		smc = SqlMapClientFactory.getSqlMapClient();
	}

	public static AdminDAO getInstance() {
		if (dao == null)
			dao = new AdminDAO();
		return dao;
	}

	// insert
	public int insertAdmin(AdminVO vo) {
		int success = 0;
		try {
			Object object = smc.insert("admin.insertAdmin", vo);
			if (object == null) {
				success = 1;
			}
		} catch (SQLException e) {
			success = 0;
			e.printStackTrace();
		}
		return success;
	}

	// delete
	public int deleteAdmin(String adminId) {
		int success = 0;
		try {
			success = smc.delete("admin.deleteAdmin", adminId);

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return success;
	}

	// selectAll
	public List<AdminVO> getAllAdmin() {
		List<AdminVO> list = new ArrayList<AdminVO>();

		try {
			list = smc.queryForList("admin.getAllAdmin");

		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}

		return list;
	}

	// selectOne
	public String getAdminOne(String adminId) {
		String result = "";
		try {
			result = (String) smc.queryForObject("admin.getAdminOne", adminId);

		} catch (SQLException e) {
			result = null;
			e.printStackTrace();
		}
		return result;
	}

	// selectCount
	public int getAdminCount(String adminId) {
		int count = 0;

		try {
			count = (int) smc.queryForObject("admin.getAdminCount", adminId);

		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}
		return count;
	}

}
