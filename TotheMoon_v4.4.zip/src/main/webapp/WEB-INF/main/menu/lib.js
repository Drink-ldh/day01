//
//
//$(function(){
//	$api_key = "878f69284d01314ac7fbb82985236d86";
//	$search_city = urlencode($_POST["search_city"]);
//	
//	$url = "api.openweathermap.org/data/2.5/weather?q=".$search_city."&appid=".$api_key;
//
//	
//	$is_post = false;
//	$ch = curl_init();
//	curl_setopt($ch, CURLOPT_URL, $url);
//	curl_setopt($ch, CURLOPT_POST, $is_post);
//	curl_setopt($ch, CURLOPT_RETURNTRAINSFER, true);
//	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
//	
//	$response = curl_exec ($ch);
//	$state_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
//	curl_close ($ch);
//	if($state_code == 200)
//		{
//		echo $response;
//		}
//	
//	)}
//
//
