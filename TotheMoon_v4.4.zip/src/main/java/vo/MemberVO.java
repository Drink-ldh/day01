package vo;

public class MemberVO {
	private String mem_code;
	private String mem_nickname;
	private String mem_pass;
	
	public MemberVO(String mem_code, String mem_nickname) {
		this.mem_code = mem_code;
		this.mem_nickname = mem_nickname;
	}
	
	public MemberVO(String mem_code, String mem_nickname, String mem_pass) {
		this.mem_code = mem_code;
		this.mem_nickname = mem_nickname;
		this.mem_pass = mem_pass;
	}
	
	public MemberVO() {
	}
	public String getMem_code() {
		return mem_code;
	}
	public void setMem_code(String mem_code) {
		this.mem_code = mem_code;
	}
	public String getMem_nickname() {
		return mem_nickname;
	}
	public void setMem_nickname(String mem_nickname) {
		this.mem_nickname = mem_nickname;
	}

	public String getMem_pass() {
		return mem_pass;
	}

	public void setMem_pass(String mem_pass) {
		this.mem_pass = mem_pass;
	}
	
	@Override
	public String toString() {
		return "MemberVO02 [mem_code=" + mem_code + ", mem_pass=" + mem_pass + ", mem_nickname=" + mem_nickname + "]";
	}
	


	
	
}
