package message.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.MessageService;
import vo.MessageVO;

/**
 * Servlet implementation class MessageContentController
 */
@WebServlet("/message/messageContent.do")
public class MessageContentController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("html/text; charset=utf-8;");
		MessageService service = MessageService.getInstance();
		
		String msgNo = request.getParameter("msg_no");
//		System.out.println("------------------------MessageContentController---------------------");
//		System.out.println(">>>>msgNo>>>>>>>>>"+msgNo);
		
		MessageVO mvo = service.viewContent(msgNo);
		service.messageCheck(msgNo);
		//		System.out.println(">>>>>>>>>>>>>"+mvo);
		request.setAttribute("messageVO", mvo);
		
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/messageContent.jsp");
		rd.forward(request, response);
		
		
		response.flushBuffer();
//		System.out.println("-----------------------------------------------------------------------");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
