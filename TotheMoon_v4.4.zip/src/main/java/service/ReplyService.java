package service;

import java.util.List;

import dao.ReplyDAO;
import vo.ReplyVO;

public class ReplyService {
	private ReplyDAO dao;

	private static ReplyService service;

	private ReplyService() {
		dao = ReplyDAO.getInstance();
	}

	public static ReplyService getInstance() {
		if (service == null)
			service = new ReplyService();
		return service;
	}

	// insert
	public int insertReply(ReplyVO rvo) {
		return dao.insertReply(rvo);
	}

	// delete
	public int deleteReply(int replyNo) {
		return dao.deleteReply(replyNo);
	}

	// update
	public int updateReply(ReplyVO rvo) {
		return dao.updateReply(rvo);
	}

	// selectAll
	public List<ReplyVO> getAllReplyList() {
		return dao.getAllReplyList();
	}

	// selectCount
	public int getReplyCount(int replyNo) {
		return dao.getReplyCount(replyNo);
	}

	// replyOfBoard
	public List<ReplyVO> replyOfBoard(String boardNo) {
		return dao.replyOfBoard(boardNo);
	}
	
	public ReplyVO getRecentReply(String memCode) {
		return dao.getRecentReply(memCode);
	}
	
	public ReplyVO selectByNo(int no) {
		return dao.selectByNo(no);
	}
	
	
}
