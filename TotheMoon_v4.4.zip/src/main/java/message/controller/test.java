package message.controller;

public class test {
	public static void main(String[] args) {
		String content = "답장<br>줄바꿈<br>안됩니다.";
		System.out.println(content.indexOf("<b1r>"));
		System.out.println(content.substring(0, content.indexOf("<br>")));
	}

}
