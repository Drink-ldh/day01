package dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import util.SqlMapClientFactory;
import vo.UpbitVO;

public class UpbitDAO {
	private static UpbitDAO dao;

	private SqlMapClient smc; // ibatis용 SqlMapClient객체 변수 선언

	private UpbitDAO() {
		smc = SqlMapClientFactory.getSqlMapClient();
	}

	public static UpbitDAO getInstance() {
		if (dao == null)
			dao = new UpbitDAO();
		return dao;
	}

	// insert
	public int insertUpbit(UpbitVO uvo) {
		int cnt = 0;
		try {
			Object obj = smc.insert("upbit.insertUpbit", uvo);
			if (obj == null) {
				cnt = 1;
			}

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// delete
	public int deleteUpbit(String memCode) {
		int cnt = 0;
		try {
			cnt = smc.delete("upbit.deleteUpbit", memCode);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// selectAll
	public List<UpbitVO> getAllUpbitList() {
		List<UpbitVO> list = null;
		try {
			list = smc.queryForList("upbit.getAllUpbitList");
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}

		return list;
	}

	// selectCount
	public int getUpbitCount(String memCode) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("upbit.getUpbitCount", memCode);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}

		return count;
	}

	// selectOne
	public UpbitVO getUpbitOne(String memCode) {
		UpbitVO uvo = null;
		try {
			uvo = (UpbitVO) smc.queryForObject("upbit.getUpbitOne", memCode);
		} catch (SQLException e) {
			uvo = null;
			e.printStackTrace();
		}

		return uvo;
	}
}
