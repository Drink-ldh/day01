package board.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.BoardService;
import service.ReplyService;
import vo.BoardVO;
import vo.ReplyVO;

/**
 * Servlet implementation class BoardContentController
 */
@WebServlet("/board/boardContent.do")
public class BoardContentController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String board_no = request.getParameter("board_no");
		
		BoardService service = BoardService.getInstance();
		ReplyService replyService = ReplyService.getInstance();

		BoardVO bvo = service.viewContent(board_no);
		List<ReplyVO> replyList = replyService.replyOfBoard(board_no);
		
		request.setAttribute("BoardVO", bvo);
		request.setAttribute("replyList", replyList);

		
		RequestDispatcher rd = 
				request.getRequestDispatcher("/WEB-INF/view/boardContent.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
