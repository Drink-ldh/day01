//package dao;
//
//import java.sql.SQLException;
//import java.util.List;
//import java.util.Map;
//
//import com.ibatis.sqlmap.client.SqlMapClient;
//
//import util.SqlMapClientFactory;
//import vo.MemberVO02;
//
//public class MemberDaoImpl implements IMemberDao {
//	private static MemberDaoImpl dao;
//
//	private SqlMapClient smc;
//
//	private MemberDaoImpl() {
//		smc = SqlMapClientFactory.getSqlMapClient();
//	}
//
//	public static MemberDaoImpl getInstance() {
//		if(dao==null) dao = new MemberDaoImpl();
//		return dao;
//	}
//
//
//	@Override
//	public int insertMember02(MemberVO02 memvo) {
//		int cnt = 0;
//		try {
//			Object obj = smc.insert("member.insertMember02", memvo);
//			if(obj==null) {
//				cnt = 1;
//			}
//
//		} catch (SQLException e) {
//			cnt = 0;
//			e.printStackTrace();
//		}
//
//		return cnt;
//	}
//
//	@Override
//	public int deleteMember02(String memId) {
//		int cnt = 0;
//		try {
//			cnt = smc.delete("member.deleteMember02", memId);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//
//		return cnt;
//	}
//
//
//	@Override
//	public List<MemberVO02> getAllMemberList() {
//		List<MemberVO02> memList = null;
//		try {
//			memList = smc.queryForList("member.getAllMember02");
//		} catch (SQLException e) {
//			memList = null;
//			e.printStackTrace();
//		}
//
//		return memList;
//	}
//
//	@Override
//	public int getMemberCount02(String memId) {
//		int count = 0;
//		try {
//			count = (int) smc.queryForObject("member.getMemberCount02", memId);
//		} catch (SQLException e) {
//			count = 0;
//			e.printStackTrace();
//		}
//
//		return count;
//	}
//
//	@Override
//	public int updateMemeber02(Map<String, String> paramMap) {
//		int cnt = 0;
//		try {
//			cnt = smc.update("member.updateMember02", paramMap);
//
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//
//		return cnt;
//	}
//
//	@Override
//	public MemberVO02 getMember02(String memId) {
//		MemberVO02 memVo = null;
//		try {
//			memVo = (MemberVO02) smc.queryForObject("member.getMember02", memId);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return memVo;
//	}
//
//	@Override
//	public MemberVO02 login02(MemberVO02 memVO) {
//		MemberVO02 memVo = null;
//		try {
//			memVo = (MemberVO02) smc.queryForObject("member.login02", memVO);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return memVo;
//	}
//
//	@Override
//	public MemberVO02 logout02(MemberVO02 memVO) {
//		MemberVO02 memVo = null;
//		try {
//			memVo = (MemberVO02) smc.queryForObject("member.logout02", memVO);
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//		return memVo;
//	}
//
//
//
//}
