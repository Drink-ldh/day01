package service;

import java.util.List;

import dao.WordDAO;
import vo.WordVO;

public class WordService {
	private WordDAO dao;

	private static WordService service;

	private WordService() {
		dao = WordDAO.getInstance();
	}

	public static WordService getInstance() {
		if (service == null)
			service = new WordService();
		return service;
	}

	// insert
	public int insertWord(String word) {
		return dao.insertWord(word);
	}

	// delete
	public int deleteWord(String word) {
		return dao.deleteWord(word);
	}

	// selectAll
	public List<WordVO> getAllWordList() {
		return dao.getAllWordList();
	}

	// selectCount
	public int getWordCount(String word) {
		return dao.getWordCount(word);
	}

	// selectOne
	public WordVO getWordOne(String word) {
		return dao.getWordOne(word);
	}
}
