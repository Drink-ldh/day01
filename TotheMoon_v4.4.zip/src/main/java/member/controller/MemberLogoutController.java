package member.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class MemberLogoutController
 */
@WebServlet("/member/memberLogout.do")
public class MemberLogoutController extends HttpServlet {
   private static final long serialVersionUID = 1L;


   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   request.setCharacterEncoding("utf-8");
	   response.setCharacterEncoding("UTF-8");
	   
	   // 로그아웃은 세션을 삭제하면 된다.
      HttpSession session = request.getSession();
      System.out.println(session.getAttribute("code"));
      session.invalidate(); // 세션 삭제
      
      
//      RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/main/starmoon.jsp");
       request.getRequestDispatcher("/testServlet").forward(request, response); 
     // response.sendRedirect(request.getContextPath() + "/testServlet");
      System.out.println("뛰기");
   }
 

   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      // TODO Auto-generated method stub
      doGet(request, response);
   }

}