package util;


import dao.BoardDAO;
import vo.BoardVO;

public class test {
	public static void main(String[] args) {
//	List<CoinVO> list = dao.searchCoinByCode("BTC");
//	System.out.println(list.get(0).getCoin_content());
	  
	BoardDAO dao = BoardDAO.getInstance();
	BoardVO bvo = new BoardVO("이더리움 게시판이라네~", "일빠", "a001","123");
	dao.insertEthBoard(bvo);
	
	
	  
	
	
	}
}
