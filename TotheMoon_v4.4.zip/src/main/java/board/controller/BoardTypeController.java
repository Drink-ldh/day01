package board.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import service.BoardService;
import vo.BoardVO;

@WebServlet("/board/boardType.do")
public class BoardTypeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("application/json; charset=utf-8");
		
		String start = request.getParameter("start");
		System.out.println(start);
		String end = request.getParameter("end");
		String coin = request.getParameter("coin_code");
		
		Map<String, String> map = new HashMap<>();
		map.put("start", start);
		map.put("end", end);
		
		BoardService service = BoardService.getInstance();
		List<BoardVO> list = null;
		switch(coin) {
		case "All" : 
		case "ALL" : 
//			list = service.displayBoardList();
			list = service.selectAll(map);
			System.out.println("type서블릿>>" + map);
			break;
		default : 
//			list = service.classifByCoin(coin);
			map.put("coin_code", coin);
			list = service.selectByCoin(map);
			System.out.println("type서블릿>>" + map);
		}
		
		Gson gson = new Gson();
		String jsonData = gson.toJson(list);
		PrintWriter out = response.getWriter();
		out.println(jsonData);
		response.flushBuffer();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
