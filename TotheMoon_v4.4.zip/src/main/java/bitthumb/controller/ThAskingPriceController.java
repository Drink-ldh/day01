package bitthumb.controller;

public class ThAskingPriceController {

}
