package service;

import java.util.List;

import dao.UpbitDAO;
import vo.UpbitVO;

public class UpbitService {
	private UpbitDAO dao;

	private static UpbitService service;

	private UpbitService() {
		dao = UpbitDAO.getInstance();
	}

	public static UpbitService getInstance() {
		if (service == null)
			service = new UpbitService();
		return service;
	}

	// insert
	public int insertUpbit(UpbitVO uvo) {
		return dao.insertUpbit(uvo);
	}

	// delete
	public int deleteUpbit(String memCode) {
		return dao.deleteUpbit(memCode);
	}

	// selectAll
	public List<UpbitVO> getAllUpbitList() {
		return dao.getAllUpbitList();
	}

	// selectCount
	public int getUpbitCount(String memCode) {
		return dao.getUpbitCount(memCode);
	}

	// selectOne
	public UpbitVO getUpbitOne(String memCode) {
		return dao.getUpbitOne(memCode);
	}
}
