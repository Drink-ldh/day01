package vo;

public class BoardVO {
	private String board_no;
	private String board_title;
	private String board_content;
	private String board_date;
	private String board_hit;
	private String board_like;
	private String mem_code;
	private String img_id;
	private String coin_code;
	private String mem_nickname;
	
	public BoardVO(String board_no, String board_title, String board_content, String board_date, String board_hit,
			String board_like, String mem_code, String img_id, String coin_code, String mem_nickname) {
		this.board_no = board_no;
		this.board_title = board_title;
		this.board_content = board_content;
		this.board_date = board_date;
		this.board_hit = board_hit;
		this.board_like = board_like;
		this.mem_code = mem_code;
		this.img_id = img_id;
		this.coin_code = coin_code;
		this.mem_nickname = mem_nickname;
	}
	public BoardVO() {
	}
	
	
	
	public String getBoard_no() {
		return board_no;
	}
	public void setBoard_no(String board_no) {
		this.board_no = board_no;
	}
	public String getBoard_title() {
		return board_title;
	}
	public void setBoard_title(String board_title) {
		this.board_title = board_title;
	}
	public String getBoard_content() {
		return board_content;
	}
	public void setBoard_content(String board_content) {
		this.board_content = board_content;
	}
	public String getBoard_date() {
		return board_date;
	}
	public void setBoard_date(String board_date) {
		this.board_date = board_date;
	}
	public String getBoard_hit() {
		return board_hit;
	}
	public void setBoard_hit(String board_hit) {
		this.board_hit = board_hit;
	}
	public String getBoard_like() {
		return board_like;
	}
	public void setBoard_like(String board_like) {
		this.board_like = board_like;
	}
	public String getMem_code() {
		return mem_code;
	}
	public void setMem_code(String mem_code) {
		this.mem_code = mem_code;
	}
	public String getImg_id() {
		return img_id;
	}
	public void setImg_id(String img_id) {
		this.img_id = img_id;
	}
	public String getCoin_code() {
		return coin_code;
	}
	public void setCoin_code(String coin_code) {
		this.coin_code = coin_code;
	}
	public String getMem_nickname() {
		return mem_nickname;
	}
	public void setMem_nickname(String mem_nickname) {
		this.mem_nickname = mem_nickname;
	}
	public BoardVO(String board_title, String board_content, String mem_code, String coin_code) {
		this.board_title = board_title;
		this.board_content = board_content;
		this.mem_code = mem_code;
		this.coin_code = coin_code;
	}
}
