package service;

import java.sql.SQLException;
import java.util.List;

import dao.MemberDAO;
import vo.MemberVO;

public class MemberService {
	private MemberDAO dao;

	private static MemberService service;

	private MemberService() {
		dao = MemberDAO.getInstance();
	}

	public static MemberService getInstance() {
		if (service == null)
			service = new MemberService();
		return service;
	}

	// insert
	public int insertMember(MemberVO mvo) {
		return dao.insertMember(mvo);
	}

	// update
	public int updateMember(MemberVO mvo) {
		return dao.updateMember(mvo);
	}

	// selectAll
	public List<MemberVO> getAllMemberList() {
		return dao.getAllMemberList();
	}

	// selectCount
	public int getMemberCount(String memCode) {
		return dao.getMemberCount(memCode);
	}

	// selectByMemCode
	public MemberVO selectByMemCode(String memCode) {
		return dao.selectByMemCode(memCode);
	}

	// searchByMemCode
	public List<MemberVO> searchByMemCode(String memCode) {
		return dao.searchByMemCode(memCode);
	}

	// seachByMemNickname
	public List<MemberVO> seachByMemNickname(String memNickname) {
		return dao.seachByMemNickname(memNickname);
	}
	
	public MemberVO login02(MemberVO memVO) {
		return dao.login02(memVO);
	}
}
