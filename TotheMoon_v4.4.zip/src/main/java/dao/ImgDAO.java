package dao;

import java.sql.SQLException;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import util.SqlMapClientFactory;
import vo.ImgVO;

public class ImgDAO {
	private static ImgDAO dao;

	private SqlMapClient smc; // ibatis용 SqlMapClient객체 변수 선언

	private ImgDAO() {
		smc = SqlMapClientFactory.getSqlMapClient();
	}

	public static ImgDAO getInstance() {
		if (dao == null)
			dao = new ImgDAO();
		return dao;
	}

	// insert
	public int insertImg(ImgVO ivo) {
		int cnt = 0;
		try {
			Object obj = smc.insert("img.insertImg", ivo);
			if (obj == null) {
				cnt = 1;
			}

		} catch (SQLException e) {
			cnt = 0;
			e.printStackTrace();
		}

		return cnt;
	}

	// delete
	public int deleteImg(String imgId) {
		int cnt = 0;
		try {
			cnt = smc.delete("img.deleteImg", imgId);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// update
	public int updateImg(ImgVO ivo) {
		int cnt = 0;

		try {
			cnt = smc.update("img.updateImg", ivo);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cnt;
	}

	// selectAll
	public List<ImgVO> getAllImgList() {
		List<ImgVO> list = null;
		try {
			list = smc.queryForList("img.getAllImgList");
		} catch (SQLException e) {
			list = null;
			e.printStackTrace();
		}

		return list;
	}

	// selectCount
	public int getImgCount(String imgId) {
		int count = 0;
		try {
			count = (int) smc.queryForObject("img.getImgCount", imgId);
		} catch (SQLException e) {
			count = 0;
			e.printStackTrace();
		}

		return count;
	}

	// selectOne
	public ImgVO getImgOne(String imgId) {
		ImgVO ivo = null;
		try {
			ivo = (ImgVO) smc.queryForObject("img.getImgOne", imgId);
		} catch (SQLException e) {
			ivo = null;
			e.printStackTrace();
		}

		return ivo;
	}
}
