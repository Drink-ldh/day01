package service;

import java.util.List;

import dao.ImgDAO;
import vo.ImgVO;

public class ImgService {
	private ImgDAO dao;

	private static ImgService service;

	private ImgService() {
		dao = ImgDAO.getInstance();
	}

	public static ImgService getInstance() {
		if (service == null)
			service = new ImgService();
		return service;
	}

	// insert
	public int insertImg(ImgVO ivo) {
		return dao.insertImg(ivo);
	}

	// delete
	public int deleteImg(String imgId) {
		return dao.deleteImg(imgId);
	}

	// update
	public int updateImg(ImgVO ivo) {
		return dao.updateImg(ivo);	
	}

	// selectAll
	public List<ImgVO> getAllImgList() {
		return dao.getAllImgList();
	}

	// selectCount
	public int getImgCount(String imgId) {
		return dao.getImgCount(imgId);
	}

	// selectOne
	public ImgVO getImgOne(String imgId) {
		return dao.getImgOne(imgId);
	}
}
