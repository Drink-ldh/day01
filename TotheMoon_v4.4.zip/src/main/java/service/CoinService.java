package service;

import java.util.List;

import dao.CoinDAO;
import vo.CoinVO;

public class CoinService {
	private CoinDAO dao;

	private static CoinService service;

	private CoinService() {
		dao = CoinDAO.getInstance();
	}

	public static CoinService getInstance() {
		if (service == null)
			service = new CoinService();
		return service;
	}

	// insert
	public int insertCoin(CoinVO cvo) {
		return dao.insertCoin(cvo);
	}

	// delete
	public int deleteCoin(String coinCode) {
		return dao.deleteCoin(coinCode);
	}

	// update
	public int updateCoin(CoinVO cvo) {
		return dao.updateCoin(cvo);
	}

	// selectAll
	public List<CoinVO> getAllCoinList() {
		return dao.getAllCoinList();
	}

	// selectCount
	public int getCoinCount(String coinCode) {
		return dao.getCoinCount(coinCode);
	}

	// viewContent
	public CoinVO viewContent(String coinCode) {
		return dao.viewContent(coinCode);
	}

	// searchByCode
	public List<CoinVO> searchCoinByCode(String keyword) {
		return dao.searchCoinByCode(keyword); 
	}

	// searchByKorName
	public List<CoinVO> searchCoinByKnm(String keyword) {
		return dao.searchCoinByKnm(keyword);
	}

	// searchByEngName
	public List<CoinVO> searchCoinByEnm(String keyword) {
		return dao.searchCoinByEnm(keyword);
	}
}
