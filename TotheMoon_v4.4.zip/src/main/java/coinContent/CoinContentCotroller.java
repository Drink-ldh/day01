package coinContent;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import service.CoinService;
import vo.CoinVO;

/**
 * Servlet implementation class CoinCointentCotroller
 */
@WebServlet("/coin/coinContent.do")
public class CoinContentCotroller extends HttpServlet {
	private static final long serialVersionUID = 1L;


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");

		response.setCharacterEncoding("utf-8");

		response.setContentType("application/json; utf-8");

		String code = request.getParameter("code");

		CoinService service = CoinService.getInstance();

		CoinVO vo = service.viewContent(code);

		Gson gson = new Gson();
		String gsondata = gson.toJson(vo);
		PrintWriter out = response.getWriter();
		out.print(gsondata);
		response.flushBuffer();

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
