package notice.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.NoticeService;

@WebServlet("/admin/adminNoticeDelete.do")
public class AdminNoticeDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String noticeStr = request.getParameter("notice_no");
		int noticeNo = Integer.parseInt(noticeStr);
		
		NoticeService service = NoticeService.getInstance();

		service.deleteNotice(noticeNo);

		response.sendRedirect(request.getContextPath() + "/notice/noticeList.do?type=admin");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

} 
