package upbit.controller;

public class UpRecentTradeController {

}
