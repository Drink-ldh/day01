package message.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import service.MemberService;
import service.MessageService;
import vo.MemberVO;
import vo.MessageVO;

/**
 * Servlet implementation class SendMessageController
 */
@WebServlet("/message/sendMessage.do")
public class SendMessageController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("html/text; charset=utf-8;");
//		MessageService service = MessageService.getInstance();
		MemberService service = MemberService.getInstance();
		
		List<MemberVO> list = service.getAllMemberList();
		
		String user = request.getParameter("user");
		String receiver_code = request.getParameter("member");
		
		request.setAttribute("user", user);
		request.setAttribute("member", receiver_code);
		request.setAttribute("memberList", list);
		
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/sendForm.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("html/text; charset=utf-8;");
		MessageService service = MessageService.getInstance();
		String receiver_code = request.getParameter("member");
		String text = request.getParameter("messageText").replaceAll("\r\n|\r|\n", "<br>");
		String sender_code = request.getParameter("user");
		
		MessageVO mvo = new MessageVO(text, sender_code, receiver_code);
		
		service.insertMessage(mvo);
		
		Gson gson = new Gson();
		PrintWriter out = response.getWriter();
		out.println(gson.toJson(mvo));
	}

}
