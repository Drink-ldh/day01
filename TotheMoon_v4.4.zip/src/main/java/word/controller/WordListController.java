package word.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.WordService;
import vo.WordVO;

@WebServlet("/admin/wordList.do")
public class WordListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		WordService service = WordService.getInstance();

		List<WordVO> list = service.getAllWordList();

		request.setAttribute("wordList", list);
		RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/view/adminWordList.jsp");
			rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
