package service;

import java.util.List;
import java.util.Map;

import dao.BoardDAO;
import vo.BoardVO;

public class BoardService {
	private BoardDAO dao;

	private static BoardService service;

	private BoardService() {
		dao = BoardDAO.getInstance();
	}

	public static BoardService getInstance() {
		if (service == null)
			service = new BoardService();
		return service;
	}
	
	public int countAll() {
		return dao.countAll();
	}
	public int countByCoin(String coin_code) {
		return dao.countByCoin(coin_code);
	}
	
	public List<BoardVO> selectAll(Map<String, String> map) {
		return dao.selectAll(map);
	}
	
	public List<BoardVO> selectByCoin(Map<String, String> map) {
		return dao.selectByCoin(map);
	}
	
	
	// insertCoin
	public String insertBoard(BoardVO bvo) {
		dao.insertBoard(bvo);
		return dao.getRecentPost(bvo.getMem_code()).getBoard_no();
	}

	// insertBtc
	public String insertBtcBoard(BoardVO bvo) {
		dao.insertBtcBoard(bvo);
		return dao.getRecentPost(bvo.getMem_code()).getBoard_no();
	}

	// insertEth
	public String insertEthBoard(BoardVO bvo) {
		dao.insertEthBoard(bvo);
		return dao.getRecentPost(bvo.getMem_code()).getBoard_no();
	}

	// insertXrp
	public String insertXrpBoard(BoardVO bvo) {
		dao.insertXrpBoard(bvo);
		return dao.getRecentPost(bvo.getMem_code()).getBoard_no();
	}

	// insertDoge
	public String insertDogeBoard(BoardVO bvo) {
		dao.insertDogeBoard(bvo);
		return dao.getRecentPost(bvo.getMem_code()).getBoard_no();
	}

	// delete
	public int deleteBoard(String boardNo) {
		return dao.deleteBoard(boardNo);
	}

	// update
	public int updateBoard(BoardVO bvo) {
		return dao.updateBoard(bvo);
	}

	// selectAll
	public List<BoardVO> getAllBoardList() {
		return dao.getAllBoardList();
	}

	// displayBoardList (user용)
	public List<BoardVO> displayBoardList() {
		return dao.displayBoardList();
	}

	// classifByCoin
	public List<BoardVO> classifByCoin(String coinCode) {
		return dao.classifByCoin(coinCode);
	}

	// selectCount
	public int getBoardCount(String boardNo) {
		return dao.getBoardCount(boardNo);
	}

	// searchByTitle
	public List<BoardVO> searchBoardByTitle(String keyword) {
		return dao.searchBoardByTitle(keyword);
	}

	// searchByMember
	public List<BoardVO> searchBoardByMember(String keyword) {
		return dao.searchBoardByMember(keyword);
	}

	// viewContent
	public BoardVO viewContent(String boardNo) {
		dao.countHit(boardNo);
		return dao.viewContent(boardNo);
	}

	// 조회수 ++
	public int countHit(String boardNo) {
		return dao.countHit(boardNo);
	}

	// 조회수 안오르는 글 보기
	public BoardVO getContent(String boardNo) {
		return dao.viewContent(boardNo);
	}

	// 글 좋아요++
	public int countLike(String boardNo) {
		return dao.countLike(boardNo);
	}

	// imgDelete
	public int boardImgDelete(String boardNo) {
		return dao.boardImgDelete(boardNo);
	}

	// imgUpdate
	public int boardImgUpdate(BoardVO bvo) {
		return dao.boardImgUpdate(bvo);
	}
	
	
	
	
}
