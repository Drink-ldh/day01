		
	$(function(){
		
		search();
		
		
		function search(){
		
		let resultCode="";
		
		$.ajax({
    		url: "<%=request.getContextPath()%>/news/newsController.do",
    		data: {'query': $('#query').val(),
    			'sort': $('#sort').val(),
    			'display': 100 ,	// 출력 건수	
    			'start':1			// 검색 시작 위치
    		},
    		type: "post",
    		success: function(result){
//     			console.log(result);
//     			console.log(result.items);
//     			console.log(result.display);
//     			console.log(result.items[0].description);
    			
    			
				headline1 = "<a href='"+result.items[0].originallink+"'>" + result.items[0].title + "</a> <br>"
						  + result.items[0].description + "<br>";
				headline2 = "<a href='"+result.items[1].originallink+"'>" + result.items[1].title + "</a> <br>" 			
						  + result.items[1].description + "<br>";
    			
    			
    			for(let i=2; i< result.display; i++){
    				resultCode += "<a href='"+result.items[i].originallink+"'>" + result.items[i].title + "</a> <br>";
    			}
    			
    			$('#headline1').html(headline1);
    			$('#headline2').html(headline2);
    			$('#article').html(resultCode);
    		}
		});
		
// 		$.getJSON("https://openapi.naver.com/v1/search/news.json?query=coin&display=10&start=1&sort=sim", function(data){
// 		});
	};
	
	
	$('#searchBtn').on('click',function(){
		search();
	});
	
	$('#sort').on('change',function(){
		search();
	});
	
	$('#query').on('click',function(){
// 		$('#query').val("");
		$('#query').select();
	});
			
	
	
});