package vo;

public class BitthumbVO {
	private String mem_code;
	private String th_secret;
	private String th_access;
	
	public BitthumbVO(String mem_code, String th_secret, String th_access) {
		this.mem_code = mem_code;
		this.th_secret = th_secret;
		this.th_access = th_access;
	}
	public BitthumbVO() {
	}
	public String getMem_code() {
		return mem_code;
	}
	public void setMem_code(String mem_code) {
		this.mem_code = mem_code;
	}
	public String getTh_secret() {
		return th_secret;
	}
	public void setTh_secret(String th_secret) {
		this.th_secret = th_secret;
	}
	public String getTh_access() {
		return th_access;
	}
	public void setTh_access(String th_access) {
		this.th_access = th_access;
	}
	
	
}
