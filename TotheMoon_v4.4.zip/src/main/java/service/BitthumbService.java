package service;

import java.util.List;

import dao.BitthumbDAO;
import vo.BitthumbVO;

public class BitthumbService {
	private BitthumbDAO dao;

	private static BitthumbService service;

	private BitthumbService() {
		dao = BitthumbDAO.getInstance();
	}

	public static BitthumbService getInstance() {
		if (service == null)
			service = new BitthumbService();
		return service;
	}

	// insert
	public int insertBitthumb(BitthumbVO bvo) {
		return dao.insertBitthumb(bvo);
	}

	// delete
	public int deleteBitthumb(String memCode) {
		return dao.deleteBitthumb(memCode);
	}

	// selectAll
	public List<BitthumbVO> getAllBitthumbList() {
		return dao.getAllBitthumbList();
	}

	// selectCount
	public int getBitthumbCount(String memCode) {
		return dao.getBitthumbCount(memCode);
	}

	// selectOne
	public BitthumbVO getBitthumbOne(String memCode) {
		return dao.getBitthumbOne(memCode);
	}

}
