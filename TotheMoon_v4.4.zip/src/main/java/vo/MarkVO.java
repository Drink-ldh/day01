package vo;

public class MarkVO {
	private int mark_no;
	private String mem_code;
	private String coin_code;
	public MarkVO(int mark_no, String mem_code, String coin_code) {
		this.mark_no = mark_no;
		this.mem_code = mem_code;
		this.coin_code = coin_code;
	}
	public MarkVO() {
	}
	public int getMark_no() {
		return mark_no;
	}
	public void setMark_no(int mark_no) {
		this.mark_no = mark_no;
	}
	public String getMem_code() {
		return mem_code;
	}
	public void setMem_code(String mem_code) {
		this.mem_code = mem_code;
	}
	public String getCoin_code() {
		return coin_code;
	}
	public void setCoin_code(String coin_code) {
		this.coin_code = coin_code;
	}
	
	
}
